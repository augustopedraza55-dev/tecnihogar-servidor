# TecniHogar — base para servidor y base de datos

Este paquete incluye:
- El HTML de demo que adjuntaste en `public/index.html`.
- Un servidor Node.js/Express.
- Un esquema PostgreSQL inicial para pedidos, servicios, técnicos y valoraciones.

## Importante: etapa inicial
El HTML copiado sigue siendo la demo original y todavía usa `localStorage`; no está conectado a la API. El servidor ya permite comprobar la conexión a PostgreSQL y guardar pedidos con `POST /api/orders`, pero falta integrar el formulario HTML y crear autenticación segura para administrador y técnicos antes de habilitar paneles protegidos.

## Requisitos
- Node.js 20+
- Una base de datos PostgreSQL alojada
- Variables de entorno `DATABASE_URL` y opcionalmente `ALLOWED_ORIGIN`

## Ejecutar localmente
1. Crear una base PostgreSQL.
2. Ejecutar `database/schema.sql` en esa base.
3. Copiar `.env.example` a `.env` y completar `DATABASE_URL`.
4. Ejecutar `npm install` y `npm start`.
5. Abrir `http://localhost:3000/api/health`.

## Despliegue
Subí el contenido del ZIP a un repositorio GitHub. En tu servicio de alojamiento, configurá:
- Build command: `npm install`
- Start command: `npm start`
- Variable `DATABASE_URL`: cadena de conexión privada de PostgreSQL
- Variable `ALLOWED_ORIGIN`: dominio del sitio cuando ya esté publicado

No guardes contraseñas reales, claves privadas ni la cadena de conexión en archivos que se suban a GitHub.

## Próximas tareas antes de usar con clientes
1. Conectar el formulario HTML con `POST /api/orders`.
2. Migrar pedidos, precios y técnicos desde `localStorage` a la API.
3. Implementar autenticación y autorización por roles en servidor.
4. Guardar contraseñas de técnicos con hash; nunca en texto plano.
5. Proteger aprobación/rechazo de técnicos, precios, estados y datos privados de clientes.
6. Añadir actualizaciones/notificaciones y controles de acceso por pedido.
