import express from "express";
import cors from "cors";
import helmet from "helmet";
import dotenv from "dotenv";
import pg from "pg";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const { Pool } = pg;
const app = express();
const port = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes("localhost")
    ? false
    : { rejectUnauthorized: false }
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || true }));
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "../public")));

app.get("/api/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, app: "TecniHogar", database: "connected" });
  } catch (err) {
    console.error("Health/database error:", err.message);
    res.status(503).json({ ok: false, app: "TecniHogar", database: "disconnected" });
  }
});

// Public customer request endpoint. No admin secrets or database credentials are sent to browsers.
app.post("/api/orders", async (req, res) => {
  const { name, phone, address, service, problem, preferred_date = null } = req.body || {};
  if (![name, phone, address, service, problem].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Completá nombre, teléfono, dirección, servicio y descripción." });
  }
  try {
    const result = await pool.query(
      `INSERT INTO orders (customer_name, customer_phone, customer_address, service_name, problem, preferred_date)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, status, created_at`,
      [name.trim(), phone.trim(), address.trim(), service.trim(), problem.trim(), preferred_date || null]
    );
    res.status(201).json({ message: "Solicitud recibida", order: result.rows[0] });
  } catch (err) {
    console.error("Create order error:", err.message);
    res.status(500).json({ error: "No se pudo guardar el pedido. Probá nuevamente." });
  }
});

// Intentionally no public admin/technician listing or status-changing endpoints yet.
// Those require authenticated roles before they can be enabled.
app.get("/api", (_req, res) => res.json({
  app: "TecniHogar API",
  version: "1.0.0",
  endpoints: ["GET /api/health", "POST /api/orders"]
}));

app.listen(port, () => console.log(`TecniHogar server listening on ${port}`));
